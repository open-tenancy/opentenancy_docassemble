# docassemble.openTenancy

A docassemble extension.

## Author

Amy Conroy, amyeileenconroy@gmail.com

